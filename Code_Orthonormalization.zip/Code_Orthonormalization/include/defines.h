#ifndef _DEFINES_H
#define _DEFINES_H

#include <string>
#include <math.h>
#include<Eigen/Dense>

using namespace Eigen;
using namespace std;


/** 
   \file defines.h

   \brief Basic definitions used for the rest of files.
   
   Basic definitions used for the rest of files.
*/


#ifndef USE_DOUBLE
  /** 
     \brief Set the type to represent reasl.
   
     If set to 1 reals will be represented by doubles and
     if not by floats.
  */
  #define USE_DOUBLE 0
#endif


#if USE_DOUBLE
  /** \brief The type representing reals in double precision.  */
  #define real double
#else
  /** \brief The type representing reals in single precision.  */
  #define real float
#endif

/** \brief A 3x3 matrix either in double or single precision. */
typedef Eigen::Matrix<real,3,3> Matrix3;

/** \brief A vector of 3 elements either in double or single precision. */
typedef Eigen::Matrix<real,3,1> Vector3;

/** \brief A 4x4 matrix either in double or single precision. */
typedef Eigen::Matrix<real,4,4> Matrix4;

/** \brief A vector of 4 elements either in double or single precision. */
typedef Eigen::Matrix<real,4,1> Vector4;

/** \brief Sign of a number. 
    
    Sign of a number.

    \param x The number/expression whose sign we want to find out.
*/
#define sign(x) ({ typeof (x) _x = (x); (_x>0?1:(_x<0?-1:0)); })
  

#endif
