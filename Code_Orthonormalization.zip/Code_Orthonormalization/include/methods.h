#ifndef _METHODS_H
#define _METHODS_H

#include "defines.h"

/** 
   \file methods.h

   \brief Interfaces of the ortonormalization mehods.
   
   Interfaces of the ortonormalization mehods.
*/

/** 
    \brief Common interface for all orthnomalization methods.

     Common interface for all orthnomalization methods. The first
     parameter is the output corrected matrix and the second the input
     noisy matrix.

     This template is used to pass the ortonormalization function as
     a parameter.
*/
typedef void ONMethod(Matrix3&,Matrix3&);

/** 
   \brief Exact method.
   
   Implementation of the exact closed formula.

   \param X The corrected output matrix.
   \param R The input noisy matrix.
*/
void ExactMethod(Matrix3 &X,Matrix3 &R);

/** 
   \brief Approximated method.
   
   Implementation of the approximated closed formula.

   \param X The corrected output matrix.
   \param R The input noisy matrix.
*/
void ApproxMethod(Matrix3 &X,Matrix3 &R);

/** 
   \brief Cayley method.
   
   Implementation of the Cayley method.

   \param X The corrected output matrix.
   \param R The input noisy matrix.
*/
void CayleyMethod(Matrix3 &X,Matrix3 &R);

/** 
   \brief SVD-based method.
   
   Implementation of the SVD-based method using the
   SVD implemetation provided by Eigen. In particular
   we use the two-sided Jacobi SVD decomposition method 
   for rectangular matrices.

   \param X The corrected output matrix.
   \param R The input noisy matrix.
*/
void SVDMethodEigen(Matrix3 &X,Matrix3 &R);

/** 
   \brief SVD-based method.
   
   Implementation of the SVD-based method using the
   SVD implemetation described in:

     - T. Gast, C. Fu, C. Jiang and J. Teran, 
       "Implicit-shifted Symmetric QR Singular Value Decomposition of 3x3 Matrices,"
       University of California Los Angeles, 2016.
     .

   We directly interface the implementation kindly provided by the authors.

   \param X The corrected output matrix.
   \param R The input noisy matrix.
*/
void SVDMethodIQRSVD(Matrix3 &X,Matrix3 &R);




#endif
