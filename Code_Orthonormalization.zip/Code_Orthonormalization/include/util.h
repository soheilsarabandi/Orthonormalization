#ifndef _UTIL_H
#define _UTIL_H

#include "methods.h"

#include <random>

/** 
   \file util.h

   \brief Auxiliariy functions.

   Interfaces of the different auxiliary functions used in the
   ortonormalization and in the test.
*/

/** \brief Mean distance error.

    Mean distance error goes to the first column
    of the result table.
*/ 
#define MeanDstE  0

/** \brief Max distance error.

    Max distance error goes to the second column
    of the result table.
*/ 
#define MaxDstE   1

/** \brief Min distance error.

    Min distance error goes to the third column
    of the result table.
*/ 
#define MinDstE   2

/** \brief Mean orthonormality error.

    Mean distance error goes to the fouth column
    of the result table.
*/ 
#define MeanOrtoE 3

/** \brief Max orthonormality error.

    Max distance error goes to the fith column
    of the result table.
*/ 
#define MaxOrtoE  4

/** \brief Min orthonormality error.

    Min distance error goes to teh sixth column
    of the result table.
*/ 
#define MinOrtoE  5

/** \brief Average execution time.

    Average execution time goes to the seventh column
    of the result table.
*/ 
#define AverageT  6

/** \brief Array with the different noise levels.
    
    Array with the different noise levels.
*/
typedef Array<real,Dynamic,1> noise;

/** 
   \brief Generates a random quaternion.

   This function returns points with a uniform distribution on the 
   surface of a 4-sphere following the algorithm described in:

     - Marsaglia, G. "Choosing a Point from the Surface of a Sphere." Ann. Math. Stat. 43, 645-646, 1972. 
     .

   \param e The generated quaternion.
*/
void RandomQuaternion(Vector4 &e);

/** 
   \brief Quaternion to rotation matrix.

   This function returns the rotation matrix corresponding to a set of 
   Euler parameters.

   \param R The output rotation matrix.
   \param e The quaternion.
*/
void Quat2Mat(Matrix3 &R, Vector4 &e);

/** 
   \brief Generates a random matrix.

   This function returns a 3x3 matrix whose entries are random numbers 
   uniformly distributed in the interval [-errorbound, errorbound].

   \param M The output noise matrix.
   \param noiseLevel The width of the noise.
   \param gaussian true to use Gaussian distribution.
   \param e The random engine.
*/
void RandomMatrix(Matrix3 &M,real noiseLevel,bool gaussian,default_random_engine& e);

/** 
   \brief Test a particular orthonomalization matrix.

   Test a particular orthonomalization matrix method evaluating its efficiency 
   and its accuracy.

   \param method The method to evaluate. 
   \param nRep The number of randomly generated matrix to use in the evaluation.
   \param N The (nRep) noisy matrices.
   \param res The table of results (\sa MeanDstE, MaxDstE, MinDstE, MeanOrtoE, MaxOrtoE
              MinOrtoE, AverageT).
*/
void TestMethod(ONMethod *method,unsigned int nRep,Matrix3 *N,double *res);

/** 
   \brief Prints the results of the evaluation.

   Prints the statistics collected when evaluating the methods.

   \param nMethods The number of methods tested.
   \param methodLabel A label identifying each method.
   \param nResults Number of statistics collected for each method.
   \param resultLabel A label identifying each statistic.
   \param noiseTicks The number of ticks in the noise scale.
   \param noiseLevel The level of noise for each tick.
   \param results The table with all the results. This includes the statistics
                  for each method and noise tick.
*/
void PrintResults(unsigned int nMethods,string *methodLabel,
		  unsigned int nResults,string *resultLabel,
		  unsigned int noiseTicks,noise &noiseLevel,double ***results);

/** 
   \brief Saves the results of the evaluation.

   Saves the statistics collected when evaluating the methods to a file. The
   name of the file is generated using the methodLabel parameter (one separate
   file is generated for each method).

   The files are stored in the 'results' folder with extension csv.

   \param nMethods The number of methods tested.
   \param methodLabel A label identifying each method.
   \param nResults Number of statistics collected for each method.
   \param resultLabel A label identifying each statistic.
   \param gaussian true if we used Gaussian distributions for the noise.
   \param noiseTicks The number of ticks in the noise scale.
   \param noiseLevel The level of noise for each tick.
   \param results The table with all the results. This includes the statistics
                  for each method and noise tick.
*/
void SaveResults(unsigned int nMethods,string *methodLabel,
		 unsigned int nResults,string *resultLabel,
		 bool gaussian,unsigned int noiseTicks,noise &noiseLevel,double ***results);

#endif
