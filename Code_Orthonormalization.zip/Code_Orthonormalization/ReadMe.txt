This is a software accompanying the paper:

       On Closed-Form Formulas for the 3D Nearest Rotation Matrix Problem 
       by S. Sarabandi, A. Shabani, J. M. Porta and F. Thomas
     
submitted to the IEEE Transactions on Robotics.

To compile and execute this code you will need:
	- Cmake (tested with version 3.9.2)
	- make (tested with GNU Make 3.81)
	- gcc (tested with gcc version 8.1.0)
	- Matlab (only for the Matlab code also included).

To compile the test program, first, generate the makefiles:
       cd build
       cmake ..

 and then compile
       make

The default compilation uses double precision. To use single precision set the
flag USE_DOUBLE to zero in the include/defines.h file and recompile the code.
Alternatively you can indicate the precision directly at the cmake command line:
      cmake -DDOUBLE_PRECISION=OFF ..
      cmake -DDOUBLE_PRECISION=ON ..

Finally, to generate the documentation execute:
       make doc

in the 'build' folder. The html documentation can be browsed from doc/html/index.html.

To obtain the plots in the paper (Figs. 4 and 5) execute the following steps:

    Change to the main folder: cd ..
    Execute the test program: bin/testON
    Open Matlab
    Change to the 'results' folder, and
    Execute:
         [errorbound_cpp_uniform_float,error_cpp_uniform_float,time_cpp_uniform_float]=results_cpp_uniform_float();
	 PlotResults(errorbound_cpp_uniform_float,error_cpp_uniform_float);
    The average execution times (in microseconds) are obtained with:
         mean(time_cpp_uniform_float,2)*1e6
	 
    To test the methods for a particular matrix (perturbed with different levels of noise) execute
       testON -m  1 0 0 0 1 0 0 0 1 


For single precision the files and the Matlab variables end in '_double' instead of '_float'.
When using Gaussian distributions the file and variable names include '_gaussian'
instead of '_uniform'

Alternatively, you can use the csv files also stored in the 'results' folder.

The Matlab folder includes a Matlab implementation of the methods described in the paper.

For a more comprehensive documentation open 'doc/html/index.html' with your favorite web browser.

