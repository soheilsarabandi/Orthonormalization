function PlotResults(errorbound,error)

  % Labels used in the legend
  method={'ExactMethod','ApproxMethod','CayleyMethod', ...
           'SVDMethodEigen','SVDMethodIQRSVD'};
  
  % Color of the lines for each method
  color={'r','g','b','k','m'};
      
  % Log plots 
  logPlot = [false false false true true true];
  
  % In the same order as in test.h
  result={'Mean Frobenius norm','Maximum Frobenius norm',...
          'Minimum Frobenius norm','Mean orthogonality error',...
          'Maximum orthogonality error','Minimum orthogonality error'};
   
  for i=1:6    
    figure(i);
    if logPlot(i)
      semilogy(errorbound, squeeze(error(i,1,:)),color{1},'LineWidth',2);
      hold on;
      semilogy(errorbound, squeeze(error(i,2,:)),color{2},'LineWidth',2);
      semilogy(errorbound, squeeze(error(i,3,:)),color{3},'LineWidth',2);
      semilogy(errorbound, squeeze(error(i,4,:)),color{4},'LineWidth',1);
      semilogy(errorbound, squeeze(error(i,5,:)),color{5},'LineWidth',1);
    else
      plot(errorbound, squeeze(error(i,1,:)),color{1},'LineWidth',2); % Exact
      hold on;
      plot(errorbound, squeeze(error(i,2,:)),color{2},'LineWidth',2); % Approx
      plot(errorbound, squeeze(error(i,3,:)),color{3},'LineWidth',2); % Cayley
      plot(errorbound, squeeze(error(i,4,:)),color{4},'LineWidth',1); % SVD
      plot(errorbound, squeeze(error(i,5,:)),color{5},'LineWidth',1); % IQRSVD
    end
    ylabel(result{i});
    xlabel('Input error');
    legend(method{1},method{2},method{3},method{4},method{5},'Location','northwest');
    grid on;
  end
