#include "util.h"


#include <unistd.h>
#include <iostream>
#include <stdlib.h>
#include <iomanip> 
#include <chrono>
#include <fstream>

/** \file util.cpp

    \brief Implementation of the auxiliary functions.

    Implementation of the auxiliary functions.
*/


void RandomQuaternion(Vector4 &e)  
{
  bool ok=false;
  
  while (!ok)
    {
      //  create four random numbers between -1 and 1
      e=Vector4::Random();

      // normalize the randomly generated quaternion
      if (((e(0)*e(0)+e(1)*e(1))<1)&&((e(2)*e(2)+e(3)*e(3))<1))
	{
	  double norma = sqrt((1-e(0)*e(0)-e(1)*e(1))/(e(2)*e(2)+e(3)*e(3)));

	  e(2) = e(2) * norma;
	  e(3) = e(3) * norma;

	  ok=(e.norm()==1.0);
	}
    }
}

void Quat2Mat(Matrix3 &R, Vector4 &e)
{
  real e00,e01,e02,e03,e11,e12,e13,e22,e23,e33;

  e00=e(0)*e(0);
  e01=e(0)*e(1);
  e02=e(0)*e(2);
  e03=e(0)*e(3);

  e11=e(1)*e(1);
  e12=e(1)*e(2);
  e13=e(1)*e(3);
  
  e22=e(2)*e(2);
  e23=e(2)*e(3);

  e33=e(3)*e(3);
  
  R(0,0) = e00 + e11 - e22 - e33;
  R(0,1) = 2 * (e12 - e03);
  R(0,2) = 2 * (e13 + e02);

  R(1,0) = 2 * (e12 + e03);
  R(1,1) = e00 - e11 + e22 - e33;
  R(1,2) = 2 * (e23 - e01);

  R(2,0) = 2 * (e13 - e02);
  R(2,1) = 2 * (e23 + e01);
  R(2,2) = e00 - e11 - e22 + e33;

  //If e is a unit quaternion, the following instruction can be removed

  real n=(e00 + e11 + e22+ e33);
  
  R=(1/n)*R;
}

void RandomMatrix(Matrix3 &M,real noiseLevel,bool gaussian,default_random_engine& e)
{
  // We define two static variables, one for normal and another for uniform distributions
  static std::normal_distribution<real> normal(0,0.5); 
  static std::uniform_real_distribution<real> uniform(-1,1);
  
  if (gaussian)
    {
      for(unsigned int i=0;i<3;i++)
	{
	  for(unsigned int j=0;j<3;j++)
	    M(i,j)=normal(e)*noiseLevel; // 95% of samples in [-noiseLevel,noiseLevel]
	}
    }
  else
   {
     for(unsigned int i=0;i<3;i++)
       {
	 for(unsigned int j=0;j<3;j++)
	   M(i,j)=uniform(e)*noiseLevel;
       }
    } 
}

void TestMethod(ONMethod *method,unsigned int nRep,Matrix3 *N,double *res)
{
  unsigned int i;
  Matrix3 X;
  Matrix3d Xd,E1,E2,I=Matrix3d::Identity();
  Array<double,Dynamic,Dynamic> error(nRep,2);
  
  /* First we perform the orthnomalization with the only purpose of obtaining execution time */
  auto start = chrono::high_resolution_clock::now();
   
  for(i=0;i<nRep;i++)
    method(X,N[i]);
  
  auto finish = chrono::high_resolution_clock::now();
  chrono::duration<double> time = finish - start;
  res[AverageT]=time.count()/(double)nRep;

  /* Now we repeat the process to obtain the error metrics */
  for(i=0;i<nRep;i++)
    {
      method(X,N[i]);

      /* We compute the errors in double precision for accuracy */
      Xd=X.cast<double>(); // If already using doubles, this does nothing
      
      /* Distance to the original random rotation */
      E1=Xd-N[i].cast<double>();
      error(i,0)=E1.norm();
      
      /* Distance to the identity matrix */
      E2=(Xd.transpose()*Xd)-I;
      error(i,1)=E2.norm();
    }

  res[MeanDstE]=error.col(0).mean();
  res[MaxDstE]=error.col(0).maxCoeff();
  res[MinDstE]=error.col(0).minCoeff();

  res[MeanOrtoE]=error.col(1).mean();
  res[MaxOrtoE]=error.col(1).maxCoeff();
  res[MinOrtoE]=error.col(1).minCoeff();
}

void PrintResults(unsigned int nMethods,string *methodLabel,
		  unsigned int nResults,string *resultLabel,
		  unsigned int noiseTicks,noise &noiseLevel,double ***results)
{
  unsigned int i,k,l;

  cout.setf(ios::fixed, ios::floatfield);
  cout.precision(20);
  
  // Print on screen
  for(l=0;l<nResults;l++)
    {
      cout << resultLabel[l] << endl << endl;
	 
      // Top row with the labels
      for(k=0;k<nMethods;k++)
	{
	  cout << methodLabel[k];
	  if (k<nMethods-1)
	    cout << setw(26);
	  else
	    cout << endl;
	}
      
      cout << "-----------------------------------------------------------------------------------------------------------------------" << endl;

      for(i=0;i<noiseTicks;i++)
	{
	  for(k=0;k<nMethods;k++)
	    {
	      cout << results[k][i][l];
	      if (k<nMethods-1)
		cout << setw(25);
	      else
		cout << endl;
	    }
	}
      cout << endl << endl << endl;
    }
}

void SaveResults(unsigned int nMethods,string *methodLabel,
		 unsigned int nResults,string *resultLabel,
		 bool gaussian,unsigned int noiseTicks,noise &noiseLevel,double ***results)
{
  string fName;
  ofstream file;
  unsigned i,k,l;
  string suffix;
  
  #if (USE_DOUBLE)
    string precision="_double";
  #else
    string precision="_float";
  #endif
    
  if (gaussian)
    suffix="_gaussian"+precision;
  else
    suffix="_uniform"+precision;  
    
 // Save on files: one file per method with all the result (one row for each error level
  for(k=0;k<nMethods;k++)
    {
      string fname="results/"+methodLabel[k]+suffix+".csv";
      cout << "Generating file : " << fname << endl;
      
      file.open(fname);
      
      file.precision(20);
      file << fixed;
  
      // Top row with the labels of each result
      file << "N, " << "Noise, ";
      for(l=0;l<nResults;l++)
	{
	  file << resultLabel[l] ;
	  if (l<nResults-1)
	    file << ", ";
	  else
	    file << endl;
	}
      
      for(i=0;i<noiseTicks;i++)
	{
	  file << i <<  ", " <<  noiseLevel(i) << ", ";
	  for(l=0;l<nResults;l++)
	    {
	      file << results[k][i][l];
	      if (l<nResults-1)
		file << ", ";
	      else
		file << endl;
	    }
	}
      file.close();
    }

  // Save in Matlab format
  string fname="results/results_cpp"+suffix+".m";
    
  cout << "Generating file : " << fname << endl;
  
  file.open(fname);
  file << "function [errorbound_cpp"<< suffix << ",error_cpp"<< suffix << ",time_cpp"<< suffix << "]=results_cpp"<< suffix << "()"<< endl;
  file << "  %%  Error levels" << endl;
  file << "  errorbound_cpp"<< suffix << "=[";
  for(i=0;i<noiseTicks;i++)
    file << noiseLevel(i) << " ";
  file << "];" << endl<< endl;
  file << "  error_cpp"<< suffix << "=zeros("<< nResults-1 << "," << nMethods << "," << noiseTicks << ");" << endl;
  for(l=0;l<nResults;l++)
    {
      if (l!=AverageT)
	{
	  file << "  %% " << resultLabel[l] << "  (rows: method   columns: noise level)" << endl;
	  file << "  error_cpp" << suffix << "("<< (l<AverageT?l+1:l) <<",:,:)=[";
	  for(k=0;k<nMethods;k++)
	    {
	      for(i=0;i<noiseTicks;i++)
		file << results[k][i][l] << " ";
	      file << endl << "                           ";
	    }
	  file << "];"<< endl;
	}
    }
  file << "  %% Execution time  (rows: method   columns: noise level)" << endl;
  file << "  time_cpp" << suffix << "=[";
  for(k=0;k<nMethods;k++)
    {
      for(i=0;i<noiseTicks;i++)
	file << results[k][i][AverageT] << " ";
      file << endl << "                   ";
    }
  file << "];"<< endl;
  
  file.close();
}


