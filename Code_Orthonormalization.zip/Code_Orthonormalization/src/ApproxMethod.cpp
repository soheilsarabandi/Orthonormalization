#include "methods.h"
#include "util.h"

/** \file ApproxMethod.cpp

    \brief Implementation of the approximated method.

     Implementation of the approximated method.
*/

void ApproxMethod(Matrix3 &X, Matrix3 &R)
{
  Matrix4 U,U2;
  Vector4 s,q1,q2,q3,q4,q;
  MatrixXf::Index index;
  
  /* Equivalent Matlab code:
     U = [1+R(1,1)+R(2,2)+R(3,3)  R(3,2)-R(2,3)            R(1,3)-R(3,1)           R(2,1)-R(1,2) ;
          R(3,2)-R(2,3)           1+R(1,1)-R(2,2)-R(3,3)   R(1,2)+R(2,1)           R(3,1)+R(1,3) ;
          R(1,3)-R(3,1)           R(1,2)+R(2,1)            1-R(1,1)+R(2,2)-R(3,3)  R(2,3)+R(3,2) ;
          R(2,1)-R(1,2)           R(3,1)+R(1,3)            R(2,3)+R(3,2)           1-R(1,1)-R(2,2)+R(3,3)];
   */
  U(0,0) = 1+R(0,0)+R(1,1)+R(2,2);
  U(0,1) = R(2,1)-R(1,2);
  U(0,2) = R(0,2)-R(2,0);
  U(0,3) = R(1,0)-R(0,1);

  U(1,0) = U(0,1);
  U(1,1) = 1+R(0,0)-R(1,1)-R(2,2);
  U(1,2) = R(0,1)+R(1,0);
  U(1,3) = R(2,0)+R(0,2);

  U(2,0) = U(0,2);
  U(2,1) = U(1,2); 
  U(2,2) = 1-R(0,0)+R(1,1)-R(2,2);
  U(2,3) = R(1,2)+R(2,1);

  U(3,0) = U(0,3);
  U(3,1) = U(1,3);
  U(3,2) = U(2,3);
  U(3,3) = 1-R(0,0)-R(1,1)+R(2,2);
  
  /*  Equivalent Matlab code:

      [~,index] = max(sum(U.^2,2));
  */
  U2=(U.array()*U.array());
  s=U2.rowwise().sum();
  s.maxCoeff(&index);
  
  /* Equivalent Matlab code:

    q1 = sign(dot(U(index,:),U(1,:)))*U(1,:);
    q2 = sign(dot(U(index,:),U(2,:)))*U(2,:);
    q3 = sign(dot(U(index,:),U(3,:)))*U(3,:);
    q4 = sign(dot(U(index,:),U(4,:)))*U(4,:);
  */
  q1 = sign(U.row(index).dot(U.row(0)))*U.row(0);
  q2 = sign(U.row(index).dot(U.row(1)))*U.row(1);
  q3 = sign(U.row(index).dot(U.row(2)))*U.row(2);
  q4 = sign(U.row(index).dot(U.row(3)))*U.row(3);
  
  /* Equivalent Matlab code:

    X = Quat2Mat(q1+q2+q3+q4);
  */
  q = q1+q2+q3+q4;
  Quat2Mat(X,q);
}
