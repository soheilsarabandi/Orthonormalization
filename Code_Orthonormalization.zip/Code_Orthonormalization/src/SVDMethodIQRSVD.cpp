#include "methods.h"

#include "IQRSVD/ImplicitQRSVD.h"

/** \file SVDMethodIQRSVD.cpp

    \brief Implementation of the SVD-based method.

     Implementation of the SVD-based method. In particular, this
     file uses the SVD implementation described in:

       - T. Gast, C. Fu, C. Jiang and J. Teran, 
         "Implicit-shifted Symmetric QR Singular Value Decomposition of 3x3 Matrices,"
         University of California Los Angeles, 2016.
       .
*/

using namespace JIXIE;

void SVDMethodIQRSVD(Matrix3 &X,Matrix3 &R)
{
  Matrix3 U,V;
  Vector3 S;

  singularValueDecomposition(R,U,S,V);
  
  if (S(0)*S(1)*S(2)<0)
    {
      Matrix3 D = Matrix3::Identity(3,3);
      D(2,2) = -1;
      X = U*D*V.transpose();
    }
  else 
    X = U*V.transpose();
}
