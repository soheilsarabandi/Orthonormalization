#include "methods.h"
#include "util.h"

/** \file CayleyMethod.cpp

    \brief Implementation of the Cayley method.

     Implementation of the Cayley method.
*/

void CayleyMethod(Matrix3 &X,Matrix3 &R)
{
  Matrix4 U;
  Vector4 q;
  MatrixXf::Index index; // finding maximum value index of sum(U.^2)

  /* Equivalent Matlab code:

     U = [1+R(1,1)+R(2,2)+R(3,3)  R(3,2)-R(2,3)            R(1,3)-R(3,1)           R(2,1)-R(1,2) ;
          R(3,2)-R(2,3)           1+R(1,1)-R(2,2)-R(3,3)   R(1,2)+R(2,1)           R(3,1)+R(1,3) ;
          R(1,3)-R(3,1)           R(1,2)+R(2,1)            1-R(1,1)+R(2,2)-R(3,3)  R(2,3)+R(3,2) ;
          R(2,1)-R(1,2)           R(3,1)+R(1,3)            R(2,3)+R(3,2)           1-R(1,1)-R(2,2)+R(3,3)];
  */
  U(0,0) = 1+R(0,0)+R(1,1)+R(2,2);
  U(0,1) = R(2,1)-R(1,2);
  U(0,2) = R(0,2)-R(2,0);
  U(0,3) = R(1,0)-R(0,1);

  U(1,0) = U(0,1);
  U(1,1) = 1+R(0,0)-R(1,1)-R(2,2);
  U(1,2) = R(0,1)+R(1,0);
  U(1,3) = R(2,0)+R(0,2);

  U(2,0) = U(0,2);
  U(2,1) = U(1,2); 
  U(2,2) = 1-R(0,0)+R(1,1)-R(2,2);
  U(2,3) = R(1,2)+R(2,1);

  U(3,0) = U(0,3);
  U(3,1) = U(1,3);
  U(3,2) = U(2,3);
  U(3,3) = 1-R(0,0)-R(1,1)+R(2,2);

  /* Equivalent Matlab code:
    
     q = vecnorm(A,2,2);
  */
  q=U.rowwise().norm();
  
  /* Equivalent Matlab code:

     [~, index] = max(q);
  */
  q.maxCoeff(&index);

  switch (index)
    {
    case 0:
      /* Equivalent Matlab code:
        q(1) =              q(1);
        q(2) = sign(U(1,2))*q(2);
        q(3) = sign(U(1,3))*q(3);
        q(4) = sign(U(1,4))*q(4);
       */
      q(0) =              q(0);
      q(1) = sign(U(0,1))*q(1);
      q(2) = sign(U(0,2))*q(2); 
      q(3) = sign(U(0,3))*q(3);
      break;

    case 1:
      /* Equivalent Matlab code:
        q(1) = sign(U(2,1))*q(1);
        q(2) =              q(2);
        q(3) = sign(U(2,3))*q(3);
        q(4) = sign(U(2,4))*q(4);
       */
      q(0) = sign(U(1,0))*q(0);
      q(1) =              q(1);
      q(2) = sign(U(1,2))*q(2);
      q(3) = sign(U(1,3))*q(3);
      break;

    case 2:
      /* Equivalent Matlab code:
        q(1) = sign(U(3,1))*q(1);
        q(2) = sign(U(3,2))*q(2);
        q(3) =              q(3);
        q(4) = sign(U(3,4))*q(4);
       */ 
      q(0) = sign(U(2,0))*q(0);
      q(1) = sign(U(2,1))*q(1);
      q(2) =              q(2); 
      q(3) = sign(U(2,3))*q(3);
      break;

    case 3:
      /* Equivalent Matlab code:
        q(1) = sign(U(4,1))*q(1);
        q(2) = sign(U(4,2))*q(2);
        q(3) = sign(U(4,3))*q(3);
        q(4) =              q(4);
       */
      q(0) = sign(U(3,0))*q(0);
      q(1) = sign(U(3,1))*q(1);
      q(2) = sign(U(3,2))*q(2);
      q(3) =              q(3);
    }

  /* Equivalent Matlab code:
        X = Quat2Mat(q);
   */
  Quat2Mat(X,q);
}
