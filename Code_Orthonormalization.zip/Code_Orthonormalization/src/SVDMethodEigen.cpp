#include "methods.h"

/** \file SVDMethodEigen.cpp

    \brief Implementation of the SVD-based method.

     Implementation of the SVD-based method. In particular, this
     file uses the SVD implementation provided by Eigen.
*/

void SVDMethodEigen(Matrix3 &X,Matrix3 &R)
{
  /* Equivalent Matlab code:
       [U,S,V] = svd(R);
  */
  JacobiSVD<Matrix<real,Dynamic,Dynamic>>svd(R,ComputeThinU | ComputeThinV);

  /* Equivalent Matlab code:
      if (det(S)<0)
  */
  Vector3 s = svd.singularValues();
  if (s(0)*s(1)*s(2)<0)
    {
      /* Equivalent Matlab code:
            X = U*diag([1,1,-1])*V';
       */
      Matrix3 D = Matrix3::Identity(3,3);
      D(2,2) = -1;
      X = svd.matrixU()*D*svd.matrixV().transpose();
    }
  else
    /* Equivalent Matlab code:
          X = U*V';
    */
    X = svd.matrixU()*svd.matrixV().transpose();

}
