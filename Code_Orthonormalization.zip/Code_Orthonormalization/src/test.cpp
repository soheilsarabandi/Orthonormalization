#include "methods.h"
#include "util.h"

using namespace std;

#include <unistd.h>
#include <random>
#include <iostream>

/** 
   \file test.cpp

   \brief The test application.

   The test application.
*/

/**
   \brief Main test application.

   Application to test the different orthonormalization methods and to generate the files
   with the results.

   The test parameters that can be fixed at the command line are:

     - <em>-l level</em> Fixes the lower level of noise to be considered. The default is 0.
     - <em>-u level</em> Fixes the upper level of noise to be considered. The default is 0.5.
     - <em>-t ticks</em> Fixes the number of ticks used to discretize the noise range.  The default is 100.
     - <em>-m m00 m01 m02 m10 m11 m12 m20 m21 m22</em> Performs the test on the given rotation matrix.
     - <em>-r num</em> Fixes the number of random noisy rotation matrices to be used for each level of noise. 
                       The default is 1000000.
     - <em>-g</em> Uses Gaussian distributions for the noise instead of uniform ones.
     - <em>-s seed</em> Fixes the random seed. The default is initialized at radom (using the current time).
                        The results included in the paper where obtained with the random seed fixed to 1569492783.
     - <em>-p</em> Prints the results on screen (in addition to saving them to files). The default is not to print them.
     - <em>-q</em> Quiet operation. If set nothing is printed during the tests.
     .

   The outputs of the tests are stored in the <em>resuls</em> folder.
*/
int main(int argc, char **argv)
{
  // Configuration of the experiments -------------------------------------------------------------------------

  // Statistics that will be computed for each method and noise level
  // This must be in accordance with the TestMethod function in util.cpp
  unsigned int nResults=7;
  string resultLabel[nResults];
  resultLabel[MeanDstE]  = "Mean_Distance_Error";
  resultLabel[MaxDstE]   = "Max_Distance_Error";
  resultLabel[MinDstE]   = "Min_Distance_Error";
  resultLabel[MeanOrtoE] = "Mean_Ortonormality_Error";
  resultLabel[MaxOrtoE]  = "Max_Ortonormality_Error";
  resultLabel[MinOrtoE]  = "Min_Ortonormality_Error";
  resultLabel[AverageT]  = "Average_Execution_Time";
  
  // The methods that will be evaluated
  unsigned int nMethods=5;
  ONMethod *method[nMethods] = {ExactMethod,
				ApproxMethod,
				CayleyMethod,
				SVDMethodEigen,
				SVDMethodIQRSVD};
  string methodLabel[nMethods] = {"ExactMethod",
				  "ApproxMethod",
				  "CayleyMethod",
				  "SVDMethodEigen",
				  "SVDMethodIQRSVD"};

  // Parameters setting ----------------------------------------------------------------------------------------

  // default parameters
  unsigned int noiseTicks=100;
  unsigned int nRep=1000000;

  unsigned int rs=time(0);   // A random random seed
  
  real lowNoise=0.0;
  real highNoise=0.5;

  bool print=false;
  bool quiet=false;
  bool gaussian=false;
  bool fixedMatrix=false;
  // A rotation matrix (without noise)
  Matrix3 M;
  // Random quaternion
  Vector4 q;
  // Error with respect to the random rotation matrix
  Matrix3 E;
  //Format to print the user-provided matrix, if given
  IOFormat fmt(StreamPrecision, DontAlignCols, " ", " ", "", "", "", "");

  // Check if the user provided alternative parameters
  int c;
  opterr=0; // so that getopt does not generate errors
  while ((c=getopt(argc,argv,"t:mr:s:l:u:pqg"))!=-1)
    {
      switch (c)
	{
	case 't':
	  noiseTicks=(unsigned int)atoi(optarg);
	  break;
	case 'm':
	  fixedMatrix=true;
	  if ((optind+9)>argc)
	    {
	      cerr << "Not enough inputs to define a matrix" << endl;
	      exit(EXIT_FAILURE);
	    }
	  M(0,0)=(real)atof(argv[optind]);
	  M(0,1)=(real)atof(argv[optind+1]);
	  M(0,2)=(real)atof(argv[optind+2]);
	  M(1,0)=(real)atof(argv[optind+3]);
	  M(1,1)=(real)atof(argv[optind+4]);
	  M(1,2)=(real)atof(argv[optind+5]);
	  M(2,0)=(real)atof(argv[optind+6]);
	  M(2,1)=(real)atof(argv[optind+7]);
	  M(2,2)=(real)atof(argv[optind+8]);
	  optind+=9;
	  E=(M.transpose()*M)-Matrix3::Identity();
	  if ((E.norm()>1e-18)||(M.determinant()!=1.0))
	    {
	      cerr << "The input matrix is not a rotation matrix" << endl;
	      exit(EXIT_FAILURE);
	    }
	  break;
	case 'r':
	  nRep=(unsigned int)atoi(optarg);
	  break;
	case 's':
	  rs=(unsigned int)atoi(optarg);
	  break;
	case 'l':
	  lowNoise=(real)atof(optarg);
	  break;
	case 'h':
	  highNoise=(real)atof(optarg);
	  break;
	case 'p':
	  print=true;
	  break;
	case 'q':
	  quiet=true;
	  break;
	case 'g':
	  gaussian=true;
	  break;
	default:
	  cerr << "Usage: "<< argv[0] <<" [-l low_error_bound] [-h high_error_bound] [-t noise_ticks] [-m m00 m01 m02 m10 m11 m12 m20 m21 m22] [-r num_repetitions] [-s random_seed] [-g] [-p] [-q]"<< endl;
	  exit(EXIT_FAILURE);
	}
    }
  
  // Print the settings
  if (!quiet)
    {
      cout << "Executing " <<  argv[0] << " with arguments:" << endl;
      #if (USE_DOUBLE)
        cout << "    Precison                 : double" << endl;
      #else
        cout << "    Precision                : single" << endl;
      #endif
      if (fixedMatrix)
        cout << "    Input matrix         [-m]: " << M.format(fmt) << endl;
      else
	cout << "    Num. random matrices [-r]: " << nRep       << endl;
      cout << "    Low noise            [-l]: " << lowNoise   << endl;
      cout << "    High noise           [-h]: " << highNoise  << endl;
      cout << "    Noise ticks          [-t]: " << noiseTicks << endl;
      cout << "    Random seed          [-s]: " << rs         << endl;
      cout << "    Gaussian noise       [-g]: " << gaussian   << endl;
      cout << "    Print results        [-p]: " << print      << endl;
    }

  // Fix the random seed for uniform distributions
  srand(rs); 

   // Fix the random seed for uniform distributions
  default_random_engine e(rs);

  // Discretize the noise range
  noise noiseLevel = Array<real,Dynamic,1>::LinSpaced(noiseTicks,lowNoise,highNoise);  

  // Allocate space for the results of the tests --------------------------------------------------------------
  
  // A table with all the results: 'nResults' values for each method (nMethods)
  // and each error tick (noiseTicks),
  double ***results;
  results=new double**[nMethods];
  for(unsigned int k=0;k<nMethods;k++)
    {
      results[k]=new double*[noiseTicks];
      for (unsigned int i=0;i<noiseTicks;i++)
	results[k][i]=new double[nResults];
    }
  
  // Perform all the experiments for the different noise levels -----------------------------------------------      

  // The collection of noisy rotation matrices (M with added noise)
  Matrix3 *N=new Matrix3[nRep];

  // for each noise level ...
  for (unsigned int i=0;i<noiseTicks;i++)
    { 
      if (!quiet)
	cout << "Noise level: " << noiseLevel(i) << " (" << i+1 << "/" << noiseTicks << ")"<< endl;
            
      // Generate 'nRep' noisy matrices ----------------------------------------------------------
      // We use the same nosiy matrices for all the methods
      if (!quiet)
	{
	  if (fixedMatrix)
	    cout << "  Introducing noise the given matrix" << endl;
	  else
	    cout << "  Generating " << nRep << " random noisy rotation matrices" << endl;
	}
      
      for(unsigned int j=0;j<nRep;j++)
	{
	  /* If we fixed a matrix, we use it to add the noise. Otherwise we
	     generate a random matrix and then add the noise */
	  if (!fixedMatrix)
	    {
	      RandomQuaternion(q);
	      Quat2Mat(M,q);
	    }
	  if (noiseLevel(i)==0.0)
	    N[j]=M;
	  else
	    {
	      RandomMatrix(E,noiseLevel(i),gaussian,e);
	      N[j]=M+E;
	    }
	}
      
      // Check all the methods at the current noise level ----------------------------------------
      for(unsigned int k=0;k<nMethods;k++)
	{
	  if (!quiet)
	    cout << "  Testing method: " << methodLabel[k] << endl;
	  TestMethod(method[k],nRep,N,results[k][i]);
	}
    }

  // Report the results ---------------------------------------------------------------------------------------
  if ((!quiet)&&(print))
    PrintResults(nMethods,methodLabel,nResults,resultLabel,noiseTicks,noiseLevel,results);
  SaveResults(nMethods,methodLabel,nResults,resultLabel,gaussian,noiseTicks,noiseLevel,results);

  return(EXIT_SUCCESS);
    
}
