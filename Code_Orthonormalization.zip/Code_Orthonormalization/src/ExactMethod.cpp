#include "methods.h"

#include <cmath>

/** \file ExactMethod.cpp

    \brief Implementation of the exact method.

     Implementation of the exact method.
*/

void ExactMethod(Matrix3 &X,Matrix3 &R) 
{
  /* std includes definitions of these functions both for floats and doubles */
  using std::sqrt;
  using std::abs;
  using std::cos;
  using std::sin;
  using std::atan2;
  
  Matrix3 A,Q,U;
  real m,q,p,sp,theta,ctheta,stheta,l1,l2,l3,a2,a1,a0,dem,b2,b1,b0;

  /* Equivalent Matlab code:

    A  = R'*R;
 
    m = trace(A)/3;
    Q = A-m*eye(3);
    q = det(Q)/2;
    p = sum(sum(Q.^2))/6;
    sp = sqrt(p);
   */
  A = (R.transpose())*R;
  
  m = A.trace()/3;
  Q = A-m*Matrix3::Identity(3,3);
  q = Q.determinant()/2;
  p=(Q.array()*Q.array()).sum()/6;
  sp = sqrt(p);

  /* Equivalent Matlab code:

    theta = atan2(sqrt(abs(p^3-q^2)), q)/3;
 
    ctheta = cos(theta);
    stheta = sin(theta);
   */
  theta = atan2(sqrt(abs(p*p*p-q*q)),q)/3;
  
  ctheta = cos(theta);
  stheta = sin(theta); 

  /* Equivalent Matlab code:

    l1 = abs(m + 2*sp*ctheta);
    l2 = abs(m - sp*(ctheta+sqrt(3)*stheta));
    l3 = abs(m - sp*(ctheta-sqrt(3)*stheta));
   */
  l1 = abs(m + 2*sp*ctheta);
  l2 = abs(m - sp*(ctheta+sqrt(3)*stheta));
  l3 = abs(m - sp*(ctheta-sqrt(3)*stheta));

  /* Equivalent Matlab code:

    a0 = sqrt(x1*x2*x3);
    a1 = sqrt(x1*x2)+sqrt(x1*x3)+sqrt(x3*x2);
    a2 = sqrt(x1)+sqrt(x2)+sqrt(x3);
  */
  a0 = sqrt(l1*l2*l3);
  a1 = sqrt(l1*l2)+sqrt(l1*l3)+sqrt(l3*l2);
  a2 = sqrt(l1)+sqrt(l2)+sqrt(l3);

  /* Equivalent Matlab code:

    dem = a0*(a2*a1-a0);
 
    b0 = (a2*a1^2 -a0*(a2^2 +a1))/dem;
    b1 = (a0+a2*(a2^2 -2*a1))/dem;
    b2 = a2/dem;
   */  
  dem = a0*(a2*a1-a0);

  b0 = (a2*a1*a1 -a0*(a2*a2 +a1))/dem;
  b1 = (a0+a2*(a2*a2-2*a1))/dem;
  b2 = a2/dem;

  /* Equivalent Matlab code:

     U = b2*A*A -b1*A +b0*eye(3);
 
     X= R*U;
   */
  U = b2*A*A-b1*A+b0*Matrix3::Identity(3,3);
  X = R*U; 
}

